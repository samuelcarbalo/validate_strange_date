from setuptools import find_packages, setup

setup(
    name="validate_strange_dates",
    version="0.1",
    packages=find_packages(),
    py_modules=["validate_strange_dates"],
)